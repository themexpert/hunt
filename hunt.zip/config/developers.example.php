<?php

/**
 * An array of developers email address.
 */
return [
  'dev@example.com'
];