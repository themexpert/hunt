<?php

/**
 * An array of developers email address.
 */
return [
  'wpkpda@gmail.com',
  'limon@themexpert.com'
];