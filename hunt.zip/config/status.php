<?php

return [
    'PENDING' => [
        'subject' => 'Wait your feature suggestion feedback',
        'message' => 'blah blah blah blah blah.....'
    ],

    'WIP' => [
        'subject' => 'Feedback now in progress',
        'message' => 'blah blah blah blah blah.....'
    ],

    'RELEASED' => [
        'subject' => 'Feedback has been released',
        'message' => 'blah blah blah blah blah.....'
    ],

    'DECLINED' => [
        'subject' => 'Feedback decline',
        'message' => 'blah blah blah blah blah.....'
    ]
];