<li>
    <a href="#">Dashboard</a>
</li>

<li>
    <a href="#">Suggest</a>
</li>

<li>
    <a href="#">Browse</a>
</li>

<li>
    <a href="#">Reports</a>
</li>

<li>
    <a href="#">Releases</a>
</li>

<li>
    <a href="#">Roadmap</a>
</li>