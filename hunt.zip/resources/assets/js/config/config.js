export default {
    BASE_URL: '',
    LANG: 'bn'
}