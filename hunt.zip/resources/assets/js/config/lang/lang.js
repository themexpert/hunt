module.exports = {
    en: require('./en'),
    bn: require('./bn')
};